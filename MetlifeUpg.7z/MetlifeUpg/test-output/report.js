$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("login.feature");
formatter.feature({
  "line": 1,
  "name": "To validate the Login Functionality of Metlife Identity Services Page",
  "description": "",
  "id": "to-validate-the-login-functionality-of-metlife-identity-services-page",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 17,
  "name": "Internet user login failed after more than four attempts.",
  "description": "",
  "id": "to-validate-the-login-functionality-of-metlife-identity-services-page;internet-user-login-failed-after-more-than-four-attempts.",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 16,
      "name": "@Test1"
    }
  ]
});
formatter.step({
  "line": 18,
  "name": "User hits application url",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "User gives invalid credentials",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "After four attempts user should be redirected to failed login page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitions.user_hits_application_url()"
});
formatter.result({
  "duration": 10950714600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitions.user_gives_invalid_credentials()"
});
formatter.result({
  "duration": 23388687700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitions.after_four_attempts_user_should_be_redirected_to_failed_login_page()"
});
formatter.result({
  "duration": 5245525900,
  "status": "passed"
});
});