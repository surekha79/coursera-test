package stepdefinitions;


import java.io.FileReader;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageFactory.LoginPOF;

public class StepDefinitions {
	
	
	LoginPOF log;
	WebDriver driver;

	    @Given("^User hits application url$")
	    public void user_hits_application_url() throws Throwable {
	    	System.setProperty("webdriver.chrome.driver","C:\\Users\\Surekha\\Downloads\\chromedriver_win32\\chromedriver.exe");
			 driver=new ChromeDriver();
	    	driver.get("https://qa.identity.metlife.com/");
	    	driver.manage().deleteAllCookies();
	    	driver.manage().window().maximize();
	    	driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	    	
	    	log = new LoginPOF(driver);
	    }

	    @When("^User enters valid username$")
	    public void user_enters_valid_username() throws Throwable {
	          log.username().sendKeys("mistestusr02");
	          Thread.sleep(1000);
	    }

	    @Then("^User is authenticated successfully and redirects to MFA code Preference$")
	    public void user_is_authenticated_successfully_and_redirects_to_mfa_code_preference() throws Throwable {
	    	Thread.sleep(2000);
	    	
	        
	    }

	    @And("^User enters valid password$")
	    public void user_enters_valid_password() throws Throwable {
	          log.password().sendKeys("Netlife17");
	          Thread.sleep(1000);
	    }

	    @And("^User clicks on login button$")
	    public void user_clicks_on_login_button() throws Throwable {
	          log.loginbutton().click();
	          Thread.sleep(3000);
	          
	          
	    }
	    @And("^User selects Email option for verification$")
	    public void user_selects_email_option_for_verification() throws Throwable {
	    	log.email().click();
	    	Thread.sleep(2000);
	    	String expected="https://qa.identity.metlife.com/auth/mfaCodePref";
	          String actual=driver.getCurrentUrl();
	          System.out.println(actual);
	          Assert.assertEquals(expected,actual);  
	    	
	    }

	    @And("^clicks on Verify me Button$")
	    public void clicks_on_verify_me_button() throws Throwable {
	          log.verifyMeButton().click();
	    }

	    @And("^User enters the verification code$")
	    public void user_enters_the_verification_code() throws Throwable {
	          log.verificationCode().sendKeys("111111");
	    }

	    @And("^clicks on Submit button$")
	    public void clicks_on_submit_button() throws Throwable {
	          log.submitBtn().click();
	          Thread.sleep(3000);
	    }

	    @And("^User is redirected to landing page$")
	    public void user_is_redirected_to_landing_page() throws Throwable {
	    	Thread.sleep(5000);
	          String expectedUrl="https://qa1.metlife.com/";
	          String actualUrl=driver.getCurrentUrl();
	          System.out.println(actualUrl);
	          Assert.assertEquals(expectedUrl, actualUrl);
	          driver.close();
	    }

	    
	    /****USER LOGIN FAILED ATTEMPTS****/

	    @When("^User gives invalid credentials$")
	    public void user_gives_invalid_credentials() throws Throwable {
	          
JSONParser jsonParser = new JSONParser();
FileReader reader = new FileReader(".\\Test data\\testData.json");
Object obj = jsonParser.parse(reader);
JSONObject usersloginsJsonobj = (JSONObject) obj;
JSONArray usersloginsArray=(JSONArray) usersloginsJsonobj.get("userlogins");

for(int i=0;i<usersloginsArray.size();i++) 
{
JSONObject users = (JSONObject) usersloginsArray.get(i);
System.out.println(users);//This prints every block - one json object
String username = (String) users.get("username");
String password = (String) users.get("password");
  System.out.println("The username in JSON is  "+username);
  System.out.println("The password in JSON is "+password);
  Thread.sleep(1000);
                log.username().clear();
	        	log.username().sendKeys(username); 
	        	Thread.sleep(1000);
	        	log.password().clear();
	        	Thread.sleep(1000);
	        	log.password().sendKeys(password);
	        	log.loginbutton().click();
	        	Thread.sleep(1000);
	        	String expected="We are sorry. We did not recognize the information you entered. Please try again.";
	        	String actual=log.errMsg().getText();
	        	System.out.println(actual);
	        	Assert.assertEquals(expected,actual);  	     
	          }
	    }

	    @Then("^After four attempts user should be redirected to failed login page$")
	    public void after_four_attempts_user_should_be_redirected_to_failed_login_page() throws Throwable {
	    	Thread.sleep(5000);
	          String expectedURL="https://qa.identity.metlife.com/public/InvalidUserError";
	          String actualURL=driver.getCurrentUrl();
	          Assert.assertEquals(expectedURL, actualURL);
	          driver.close();
	    }

	    @And("^clicks on login button$")
	    public void clicks_on_login_button() throws Throwable {
	    	Thread.sleep(1000);
	          log.loginbutton().click();
	    }

	

@Then("^User should not be able to log into application$")
public void user_should_not_be_able_to_log_into_application() throws Throwable {
      String actual=log.errMsg().getText();
      System.out.println(actual);
      String expected="We are sorry. All fields are required. Please try again.";
      Assert.assertEquals(expected,actual);
      driver.close();
      
}

@When("^User enters valid username and leaves password field as blank$")
public void user_enters_valid_username_and_leaves_password_field_as_blank() throws Throwable {
    log.username().sendKeys("mistestusr1");
}

@And("^User enters the invalid verification code$")
public void user_enters_the_invalid_verification_code() throws Throwable {
      log.verificationCode().sendKeys("000000");
}

@And("^User should not be able to successfully login to the application$")
public void user_should_not_be_able_to_successfully_login_to_the_application() throws Throwable {
    Thread.sleep(2000);  
	String expected="We are sorry. We did not recognize the validation code you entered. Please try again.";
      String actual=log.mfaErrorMsg().getText();
      Assert.assertEquals(expected, actual);
      driver.close();
}
}


	

	

