package pageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class LoginPOF {


	WebDriver driver;
	public LoginPOF(WebDriver driver)
	{
		this.driver =driver;
        PageFactory.initElements(driver,this);
	}

	
	
	@FindBy(id="USER")
	@CacheLookup // to store the element in cache memory
    WebElement username;
	
	@FindBy(id="PASSWORD")
	@CacheLookup // to store the element in cache memory
    WebElement password;
	
	
	@FindBy(css="#loginFormSubmit")
	@CacheLookup // to store the element in cache memory
    WebElement loginbutton;
	
	@FindBy(id="MfaRadioEmail")
	@CacheLookup // to store the element in cache memory
    WebElement email;
	
	@FindBy(id="passwordResetFormSubmit")
	@CacheLookup // to store the element in cache memory
    WebElement verifyMeButton;
	
	@FindBy(css="div.ml-form-field-errortext")
	@CacheLookup // to store the element in cache memory
    WebElement errMsg;
	
	@FindBy(name="mfaCode")
	@CacheLookup // to store the element in cache memory
    WebElement verificationCode;
	
	@FindBy(xpath="//*[@id='passwordResetFormSubmit']")
	@CacheLookup // to store the element in cache memory
    WebElement submitBtn;
	
	@FindBy(css="div.ml-form-field-errortext mfaError")
	@CacheLookup // to store the element in cache memory
    WebElement mfaErrormsg;
	
	@FindBy(css="input#checkbox")
	@CacheLookup // to store the element in cache memory
    WebElement rememberMe;
	
	public WebElement checkbox()
	{
		return rememberMe;
	}

	public WebElement mfaErrorMsg()
	{
		return mfaErrormsg;
	}
	
	public WebElement username()
	{
		return username;
	}
	
	public WebElement password()
	{
		return password;
	}
	
	public WebElement loginbutton()
	{
		return loginbutton;
	}
	
	public WebElement email() {
		return email;
	}
	public WebElement verifyMeButton()
	{
		return verifyMeButton;
	}
	public WebElement verificationCode()
	{
		return verificationCode;
	}
	public WebElement errMsg()
	{
		return errMsg;
	}
	public WebElement submitBtn()
	{
		return submitBtn;
	}
}
