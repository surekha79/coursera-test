# load_dataset_module.py

import pandas as pd

class DatasetLoader:
    def __init__(self, file_path):
        """
        Initializes the DatasetLoader with the provided file path.
        """
        self.file_path = file_path
        self.data = None

    def load_csv(self):
        """
        Loads the dataset from a CSV file into a pandas DataFrame.
        """
        try:
            self.data = pd.read_csv(self.file_path)
            print(f"[INFO] Dataset loaded successfully. Shape: {self.data.shape}")
            return self.data
        except FileNotFoundError:
            print("[ERROR] File not found. Please check the path.")
        except Exception as e:
            print(f"[ERROR] Failed to load dataset: {e}")

    def get_columns(self):
        """
        Returns a list of column names in the dataset.
        """
        if self.data is not None:
            return self.data.columns.tolist()
        else:
            print("[WARNING] Data not loaded yet.")
            return []

    def get_head(self, n=5):
        """
        Returns the first `n` rows of the dataset.
        """
        if self.data is not None:
            return self.data.head(n)
        else:
            print("[WARNING] Data not loaded yet.")
            return None
