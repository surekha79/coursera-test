# ui_module.py

class StrokeAppUI:
    def __init__(self):
        """
        Initializes the Stroke Prediction App UI.
        """
        self.options = {
            "1": "View first 5 records",
            "2": "Check missing values",
            "3": "Perform data cleaning",
            "4": "Show descriptive statistics",
            "5": "Plot distributions",
            "6": "Plot class distribution",
            "7": "Balance dataset",
            "8": "Train and evaluate models",
            "9": "Exit"
        }

    def display_menu(self):
        """
        Displays the main menu to the user.
        """
        print("\n=== Stroke Data Analytics App ===")
        for key, value in self.options.items():
            print(f"{key}. {value}")

    def get_user_choice(self):
        """
        Captures user's menu selection.
        """
        choice = input("Enter your choice (1-9): ")
        return choice
