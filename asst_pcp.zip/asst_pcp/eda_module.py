# eda_module.py

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.utils import resample
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif

class StrokeDataEDA:
    def __init__(self, data):
        """
        Initializes the EDA module with the dataset.
        """
        self.data = data
        self.label_encoders = {}
        self.scaler = StandardScaler()

    def check_missing_values(self):
        """
        Prints missing value counts and percentages for each column.
        """
        missing = self.data.isnull().sum()
        missing_percent = (missing / len(self.data)) * 100
        missing_info = pd.DataFrame({
            'Missing Values': missing,
            'Percentage': missing_percent
        })
        print("[INFO] Missing values:\n", missing_info[missing_info['Missing Values'] > 0])

    def clean_data(self):
        """
        Handles missing values and performs data cleaning.
        """
        df = self.data.copy()
        
        # Handle numeric missing values
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].median())
        
        # Handle categorical missing values
        categorical_cols = df.select_dtypes(include=['object']).columns
        df[categorical_cols] = df[categorical_cols].fillna(df[categorical_cols].mode().iloc[0])
        
        # Drop any remaining nulls
        df.dropna(inplace=True)
        
        print("[INFO] Missing values handled. Remaining:", df.isnull().sum().sum())
        return df

    def get_statistics(self):
        """
        Prints comprehensive descriptive statistics.
        """
        print("\n[INFO] Basic Statistics:")
        print(self.data.describe())
        
        print("\n[INFO] Skewness:")
        print(self.data.skew(numeric_only=True))
        
        print("\n[INFO] Kurtosis:")
        print(self.data.kurt(numeric_only=True))
        
        print("\n[INFO] Correlation Matrix:")
        numeric_data = self.data.select_dtypes(include=[np.number])
        correlation_matrix = numeric_data.corr()
        plt.figure(figsize=(10, 8))
        sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0)
        plt.title('Correlation Matrix')
        plt.tight_layout()
        plt.show()

    def plot_distributions(self, columns):
        """
        Enhanced distribution plots with additional statistics.
        """
        for col in columns:
            plt.figure(figsize=(15, 5))
            
            # Histogram with KDE
            plt.subplot(1, 3, 1)
            sns.histplot(self.data[col], kde=True)
            plt.title(f'Distribution of {col}')
            
            # Boxplot
            plt.subplot(1, 3, 2)
            sns.boxplot(x=self.data[col])
            plt.title(f'Boxplot of {col}')
            
            # QQ plot
            plt.subplot(1, 3, 3)
            from scipy import stats
            stats.probplot(self.data[col].dropna(), dist="norm", plot=plt)
            plt.title(f'Q-Q Plot of {col}')
            
            plt.tight_layout()
            plt.show()

    def plot_class_distribution(self, target_col):
        """
        Enhanced class distribution visualization.
        """
        plt.figure(figsize=(10, 6))
        sns.countplot(x=target_col, data=self.data)
        plt.title(f'Class Distribution for {target_col}')
        
        # Add percentage labels
        total = len(self.data)
        for p in plt.gca().patches:
            percentage = f'{100 * p.get_height() / total:.1f}%'
            plt.gca().annotate(percentage, (p.get_x() + p.get_width() / 2., p.get_height()),
                             ha='center', va='bottom')
        plt.show()

    def balance_classes(self, target_col):
        """
        Enhanced class balancing with multiple strategies.
        """
        df = self.data.copy()
        class_counts = df[target_col].value_counts()
        
        if len(class_counts) == 2:  # Binary classification
            df_majority = df[df[target_col] == class_counts.index[0]]
            df_minority = df[df[target_col] == class_counts.index[1]]
            
            # Upsample minority class
            df_minority_upsampled = resample(df_minority,
                                           replace=True,
                                           n_samples=len(df_majority),
                                           random_state=42)
            
            balanced_df = pd.concat([df_majority, df_minority_upsampled])
        else:  # Multi-class classification
            # Use SMOTE for multi-class balancing
            from imblearn.over_sampling import SMOTE
            X = df.drop(columns=[target_col])
            y = df[target_col]
            
            smote = SMOTE(random_state=42)
            X_balanced, y_balanced = smote.fit_resample(X, y)
            balanced_df = pd.concat([pd.DataFrame(X_balanced), pd.Series(y_balanced, name=target_col)], axis=1)
        
        print(f"[INFO] Class balanced. New shape: {balanced_df.shape}")
        return balanced_df

    def split_data(self, target_col, test_size=0.2, random_state=42):
        """
        Splits dataset into train and test sets.
        """
        X = self.data.drop(columns=[target_col])
        y = self.data[target_col]
        X_train, X_test, y_train, y_test = train_test_split(X, y, 
                                                            test_size=test_size, 
                                                            random_state=random_state,
                                                            stratify=y)
        print("[INFO] Data split into training and test sets.")
        return X_train, X_test, y_train, y_test
    
    def prepare_features(self, target_col):
        """
        Enhanced feature preparation with encoding and scaling.
        """
        df = self.data.copy()
        y = df[target_col]
        X = df.drop(columns=[target_col])
        
        # Handle categorical features
        for col in X.columns:
            if X[col].dtype == 'object':
                if col not in self.label_encoders:
                    self.label_encoders[col] = LabelEncoder()
                X[col] = self.label_encoders[col].fit_transform(X[col])
        
        # Scale numeric features
        numeric_cols = X.select_dtypes(include=[np.number]).columns
        X[numeric_cols] = self.scaler.fit_transform(X[numeric_cols])
        
        # Feature selection
        selector = SelectKBest(f_classif, k='all')
        selector.fit(X, y)
        
        # Plot feature importance
        plt.figure(figsize=(10, 6))
        feature_importance = pd.DataFrame({
            'Feature': X.columns,
            'Score': selector.scores_
        })
        feature_importance = feature_importance.sort_values('Score', ascending=False)
        sns.barplot(x='Score', y='Feature', data=feature_importance)
        plt.title('Feature Importance')
        plt.tight_layout()
        plt.show()
        
        return X, y


