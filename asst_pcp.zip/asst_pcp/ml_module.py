# ml_module.py

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, roc_curve, auc
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.utils.multiclass import type_of_target
import matplotlib.pyplot as plt
import seaborn as sns

class MLModelTrainer:
    def __init__(self, X_train, X_test, y_train, y_test):
        self.X_train = X_train
        self.X_test = X_test
        self.y_train = y_train
        self.y_test = y_test
        self.scaler = StandardScaler()
        self.X_train_scaled = self.scaler.fit_transform(X_train)
        self.X_test_scaled = self.scaler.transform(X_test)
        
    def train_and_evaluate_models(self):
        models = {
            "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
            "Random Forest": RandomForestClassifier(random_state=42),
            "Gradient Boosting": GradientBoostingClassifier(random_state=42)
        }

        metrics_df = pd.DataFrame(columns=['Model', 'Accuracy', 'Precision', 'Recall', 'F1-Score'])

        for name, model in models.items():
            # Train model
            model.fit(self.X_train_scaled, self.y_train)
            
            # Make predictions
            y_pred = model.predict(self.X_test_scaled)
            y_pred_proba = model.predict_proba(self.X_test_scaled)[:, 1] if hasattr(model, 'predict_proba') else None

            # Calculate metrics
            acc = accuracy_score(self.y_test, y_pred)
            prec = precision_score(self.y_test, y_pred, average='weighted', zero_division=0)
            rec = recall_score(self.y_test, y_pred, average='weighted', zero_division=0)
            f1 = f1_score(self.y_test, y_pred, average='weighted', zero_division=0)

            # Store results
            metrics_df = pd.concat([metrics_df, pd.DataFrame({
                'Model': [name],
                'Accuracy': [acc],
                'Precision': [prec],
                'Recall': [rec],
                'F1-Score': [f1]
            })], ignore_index=True)

            # Print results
            print(f"\n{name} Results:")
            print(f"Accuracy: {acc:.4f}")
            print(f"Precision: {prec:.4f}")
            print(f"Recall: {rec:.4f}")
            print(f"F1 Score: {f1:.4f}")

            # Plot confusion matrix
            plt.figure(figsize=(8, 6))
            cm = confusion_matrix(self.y_test, y_pred)
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
            plt.title(f"{name} - Confusion Matrix")
            plt.xlabel("Predicted")
            plt.ylabel("Actual")
            plt.tight_layout()
            plt.show()

            # Plot ROC curve only for binary classification
            if y_pred_proba is not None and type_of_target(self.y_test) == 'binary':
                try:
                    fpr, tpr, _ = roc_curve(self.y_test, y_pred_proba)
                    roc_auc = auc(fpr, tpr)
                    
                    plt.figure(figsize=(8, 6))
                    plt.plot(fpr, tpr, color='darkorange', lw=2, 
                            label=f'ROC curve (AUC = {roc_auc:.2f})')
                    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
                    plt.xlim([0.0, 1.0])
                    plt.ylim([0.0, 1.05])
                    plt.xlabel('False Positive Rate')
                    plt.ylabel('True Positive Rate')
                    plt.title(f'{name} - ROC Curve')
                    plt.legend(loc="lower right")
                    plt.show()
                except Exception as e:
                    print(f"[WARN] ROC curve skipped for {name} due to error: {e}")
            else:
                print(f"[INFO] ROC curve skipped for {name} (non-binary target)")

        # Plot comparison of all models
        plt.figure(figsize=(12, 6))
        metrics_df_melted = pd.melt(metrics_df, id_vars=['Model'], 
                                   value_vars=['Accuracy', 'Precision', 'Recall', 'F1-Score'],
                                   var_name='Metric', value_name='Score')
        
        sns.barplot(x='Model', y='Score', hue='Metric', data=metrics_df_melted)
        plt.title('Model Performance Comparison')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()

        return metrics_df
